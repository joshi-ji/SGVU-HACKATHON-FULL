package com.example.cybrathon2k26;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

public class MainActivity extends AppCompatActivity {

    // Layouts
    LinearLayout layoutRegister, layoutLogin, layoutDetails,
            layoutDashboard, layoutQR, layoutResult;

    // Registration
    EditText etRegName, etRegEmail, etRegPassword;
    Button btnRegister;

    // Login
    EditText etEmail, etPassword;
    Button btnLogin;

    // User Details
    EditText etName, etAge, etLocation, etPhone;
    Button btnSaveDetails;

    // Dashboard
    TextView tvDashName, tvDashAge, tvDashAddress, tvGovtId;
    Switch swName, swAge, swAddress, swGovtId;
    Button btnGenerateQR;

    // QR
    ImageView imgQR;
    TextView tvCountdown, tvResult;
    Button btnScan;

    // Utils
    SharedPreferences sp;
    Handler handler = new Handler();
    long expiryTime;

    // 🔐 GOVT VERIFICATION FLAG (future backend will control this)
    boolean isGovtIdVerified = false;   // change to true to simulate verified user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // findViewById
        layoutRegister = findViewById(R.id.layoutRegister);
        layoutLogin = findViewById(R.id.layoutLogin);
        layoutDetails = findViewById(R.id.layoutDetails);
        layoutDashboard = findViewById(R.id.layoutDashboard);
        layoutQR = findViewById(R.id.layoutQR);
        layoutResult = findViewById(R.id.layoutResult);

        etRegName = findViewById(R.id.etRegName);
        etRegEmail = findViewById(R.id.etRegEmail);
        etRegPassword = findViewById(R.id.etRegPassword);
        btnRegister = findViewById(R.id.btnRegister);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        etLocation = findViewById(R.id.etLocation);
        etPhone = findViewById(R.id.etPhone);
        btnSaveDetails = findViewById(R.id.btnSaveDetails);

        tvDashName = findViewById(R.id.tvDashName);
        tvDashAge = findViewById(R.id.tvDashAge);
        tvDashAddress = findViewById(R.id.tvDashAddress);
        tvGovtId = findViewById(R.id.tvGovtId);

        swName = findViewById(R.id.swName);
        swAge = findViewById(R.id.swAge);
        swAddress = findViewById(R.id.swAddress);
        swGovtId = findViewById(R.id.swGovtId);

        btnGenerateQR = findViewById(R.id.btnGenerateQR);

        imgQR = findViewById(R.id.imgQR);
        tvCountdown = findViewById(R.id.tvCountdown);
        btnScan = findViewById(R.id.btnScan);
        tvResult = findViewById(R.id.tvResult);

        sp = getSharedPreferences("USER_DATA", MODE_PRIVATE);

        // Initial screen
        if (!sp.contains("email")) {
            show(layoutRegister);
        } else {
            show(layoutLogin);
        }

        // Registration
        btnRegister.setOnClickListener(v -> {
            sp.edit()
                    .putString("name", etRegName.getText().toString())
                    .putString("email", etRegEmail.getText().toString())
                    .putString("password", etRegPassword.getText().toString())
                    .apply();
            show(layoutLogin);
        });

        // Login
        btnLogin.setOnClickListener(v -> {
            if (etEmail.getText().toString().equals(sp.getString("email", "")) &&
                    etPassword.getText().toString().equals(sp.getString("password", ""))) {
                show(layoutDetails);
            } else {
                Toast.makeText(this, "Invalid Login", Toast.LENGTH_SHORT).show();
            }
        });

        // Save Details
        btnSaveDetails.setOnClickListener(v -> {
            sp.edit()
                    .putInt("age", Integer.parseInt(etAge.getText().toString()))
                    .putString("location", etLocation.getText().toString())
                    .apply();

            tvDashName.setText("Name: " + sp.getString("name", ""));
            tvDashAge.setText("Age: " + sp.getInt("age", 0));
            tvDashAddress.setText("Address: " + sp.getString("location", ""));

            if (isGovtIdVerified) {
                tvGovtId.setText("Govt ID: Verified");
            } else {
                tvGovtId.setText("Govt ID: Not Verified");
            }

            show(layoutDashboard);
        });

        // ===== GENERATE QR (verification info embedded) =====
        btnGenerateQR.setOnClickListener(v -> {

            String qrData = "";

            // 🔐 VERIFICATION ASSERTION
            if (isGovtIdVerified) {
                qrData += "VERIFICATION=TRUE\n";
            } else {
                qrData += "VERIFICATION=FALSE\n";
            }

            // Selective disclosure
            if (swName.isChecked())
                qrData += tvDashName.getText() + "\n";

            if (swAge.isChecked())
                qrData += tvDashAge.getText() + "\n";

            if (swAddress.isChecked())
                qrData += tvDashAddress.getText() + "\n";

            if (swGovtId.isChecked())
                qrData += tvGovtId.getText() + "\n";

            imgQR.setImageBitmap(generateQR(qrData));
            expiryTime = System.currentTimeMillis() + 20000;
            startCountdown();
            show(layoutQR);
        });

        // ===== SCAN RESULT (what 3rd party sees) =====
        btnScan.setOnClickListener(v -> {

            if (System.currentTimeMillis() > expiryTime) {
                Toast.makeText(this, "QR expired", Toast.LENGTH_SHORT).show();
                show(layoutDashboard);
                return;
            }

            if (isGovtIdVerified) {
                tvResult.setText(
                        "USER VERIFIED\n" +
                                "Govt ID: Verified"
                );
            } else {
                tvResult.setText(
                        "USER NOT VERIFIED\n" +
                                "Govt ID: Not Verified"
                );
            }

            show(layoutResult);
        });
    }

    // Auto QR Expiry
    void startCountdown() {
        handler.removeCallbacksAndMessages(null);

        handler.post(new Runnable() {
            int sec = 20;

            @Override
            public void run() {
                tvCountdown.setText("Valid for " + sec + " sec");

                if (sec <= 0) {
                    Toast.makeText(MainActivity.this, "QR Expired", Toast.LENGTH_SHORT).show();
                    imgQR.setImageBitmap(null);
                    show(layoutDashboard);
                    return;
                }

                sec--;
                handler.postDelayed(this, 1000);
            }
        });
    }

    // Show one screen
    void show(View v) {
        layoutRegister.setVisibility(View.GONE);
        layoutLogin.setVisibility(View.GONE);
        layoutDetails.setVisibility(View.GONE);
        layoutDashboard.setVisibility(View.GONE);
        layoutQR.setVisibility(View.GONE);
        layoutResult.setVisibility(View.GONE);
        v.setVisibility(View.VISIBLE);
    }

    // QR Generator
    Bitmap generateQR(String text) {
        try {
            BitMatrix matrix = new MultiFormatWriter()
                    .encode(text, BarcodeFormat.QR_CODE, 400, 400);

            Bitmap bmp = Bitmap.createBitmap(400, 400, Bitmap.Config.RGB_565);

            for (int x = 0; x < 400; x++) {
                for (int y = 0; y < 400; y++) {
                    bmp.setPixel(x, y,
                            matrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
                }
            }
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }
}
